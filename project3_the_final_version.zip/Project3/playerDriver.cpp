//Libby Bianchi & Blake Martinez
//CSCI 1300
//Project 3

#include <string>
#include <iostream>
#include "Player.h"

int main()
{
    Player a;
    cout << a.getHealth() << endl;
    cout << a.getMovementSquares() << endl;
    return 0;
}