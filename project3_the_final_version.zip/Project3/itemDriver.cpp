//Libby Bianchi & Blake Martinez
//CSCI 1300
//Project 3

#include "Item.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
    Item x;
    cout << x.getHealingValue() << endl;
    cout << x.getItemName() << endl;
    return 0;
}